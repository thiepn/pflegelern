from __future__ import annotations
import json, os, re, unicodedata
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(os.environ.get('PFLEGELERN_ROOT', Path(__file__).resolve().parents[1] / 'p13_work'))
DATA = ROOT / 'data'

concepts = json.loads((DATA/'concepts.json').read_text(encoding='utf-8'))
cards = json.loads((DATA/'cards.json').read_text(encoding='utf-8'))
questions = json.loads((DATA/'questions.json').read_text(encoding='utf-8'))
cases_existing = json.loads((DATA/'cases.json').read_text(encoding='utf-8'))
sections = json.loads((DATA/'sections.json').read_text(encoding='utf-8'))
chapters = json.loads((DATA/'chapters.json').read_text(encoding='utf-8'))

concept_by_id={x['id']:x for x in concepts}
section_by_id={x['id']:x for x in sections}
chapter_by_id={x['id']:x for x in chapters}
cards_by_concept=defaultdict(list)
for card in cards:
    cards_by_concept[card['conceptId']].append(card)
concepts_by_section=defaultdict(list)
for c in concepts:
    if c.get('sectionId') in section_by_id:
        concepts_by_section[c['sectionId']].append(c)

# P13 intentionally creates 102 new cases, bringing the certified case bank from 18 to 120.
TARGET_NEW_CASES=102
TARGET_TOTAL_CASES=len(cases_existing)+TARGET_NEW_CASES

# Applied/safety concepts are better case anchors than bare definitions.
TYPE_PRIORITY={
    'safety_rule': 100,
    'contraindication': 96,
    'intervention': 94,
    'procedure': 92,
    'communication': 90,
    'patient_education': 88,
    'complication': 86,
    'sign': 84,
    'symptom': 82,
    'risk_factor': 80,
    'medication': 78,
    'sequence': 76,
    'principle': 68,
    'comparison': 66,
    'classification': 64,
    'normal_value': 62,
    'cause': 60,
    'definition': 52,
    'summary': 45,
}

BAD_TEXT_PATTERNS=[
    '\ufffd', '\x00', '\x01', '\x02', '\x03', '\x04', '\x05', '\x06', '\x07',
    'Aspekt 1', 'Aspekt 2', 'Was gilt bei „', 'organisa tions', 'PRC Gallen'
]

def norm(s:str)->str:
    s=unicodedata.normalize('NFKC',str(s)).lower()
    s=re.sub(r'\s+',' ',s).strip()
    return s

def clean_title(s:str)->str:
    s=re.sub(r'\s*[–-]\s*(Definition|Grundlagen|Allgemeines)\s*$','',s,flags=re.I).strip()
    s=re.sub(r'\s+',' ',s)
    return s[:90]

def usable_card(concept, card):
    # P13 only uses the approved source answer; learner-facing question stems are rebuilt
    # from the concept metadata, so old machine-like card-front phrasing is not propagated.
    back=(card.get('back') or '').strip()
    if not back or len(back)>340 or len(back.split())<5: return False
    if any(p in back for p in BAD_TEXT_PATTERNS): return False
    if re.search(r'[\x00-\x08\x0b\x0c\x0e-\x1f]',back): return False
    # Reject likely extraction truncations and known split-word remnants.
    m=re.search(r'([A-Za-zÄÖÜäöüß]+)\.$',back)
    whitelist={'ja','nein','etc','bzw','z','b','min','ml','mg','cm','m','kg','std','h','sog','ist'}
    if m and len(m.group(1))<=3 and m.group(1).lower() not in whitelist: return False
    if re.search(r'(Patien ten|teilstati\.?$|klar äu\.?$|Grund pflege|Pfle\.?$|sind sog\.$|sondern\.$|[–-] Grundlagen\.?$)',back): return False
    title=(concept.get('title') or '').strip()
    if concept.get('type')=='summary': return False
    if re.match(r'^(?:Der|Die|Das)\s+[a-zäöüß]', title): return False
    banned={'Das Gute daran','Nicht ausschalten','Menge reduzieren','Drohende Komplikation','Vorgang abbrechen','Alternative zur Pinzette','Nach Gebrauch verwerfen','Frischluft','Überleitung','Nicht implantierter','Medikamentöse Schmerz','Bakterielle Haut','Nebennierenrinden','Akute Epiglottis'}
    if not title or len(title)<4 or title in banned: return False
    return True

def concept_score(c, card):
    score=TYPE_PRIORITY.get(c.get('type'),40)
    if c.get('safetySensitive'): score += 28
    if c.get('importance')=='core': score += 20
    elif c.get('importance')=='important': score += 8
    # Prefer concise answers that can be judged reliably by a learner.
    score += max(0, 12-len((card.get('back') or '').split())/6)
    return score

def section_score(sid):
    cs=concepts_by_section[sid]
    usable=[]
    for c in cs:
        for card in cards_by_concept.get(c['id'],[]):
            if usable_card(c, card):
                usable.append((c,card)); break
    if len(usable)<2: return None
    if len({norm(clean_title(c.get('title') or '')) for c,_ in usable}) < 2: return None
    top=sorted(usable,key=lambda x:concept_score(*x),reverse=True)[:4]
    safety=sum(bool(c.get('safetySensitive')) or c.get('type')=='safety_rule' for c,_ in top)
    core=sum(c.get('importance')=='core' for c,_ in top)
    applied=sum(c.get('type') in {'safety_rule','contraindication','intervention','procedure','communication','patient_education','complication','sign','symptom','risk_factor','medication','sequence'} for c,_ in top)
    return sum(concept_score(c,card) for c,card in top[:2]) + safety*25 + core*12 + applied*8

def scenario_for(sec, chapter, selected):
    # P13 intentionally keeps the shared vignette conservative: the case frame adds no
    # clinical fact that is not already represented by the source-backed concepts.
    primary=clean_title(selected[0][0].get('title') or sec['title'])
    num=int(chapter.get('number') or 0)
    types={c.get('type') for c,_ in selected}
    if num <= 12:
        if 'communication' in types:
            return f'Im beruflichen Pflegekontext steht das Thema „{primary}“ im Mittelpunkt. Beurteile die Situation anhand der Lehrbuchangaben und berücksichtige die passende Kommunikation.'
        if any(t in types for t in {'safety_rule','procedure','sequence','contraindication'}):
            return f'Im beruflichen Pflegekontext steht das Thema „{primary}“ im Mittelpunkt. Beurteile die Situation anhand der Lehrbuchangaben und beachte die beschriebenen Sicherheits- und Handlungsregeln.'
        return f'Im beruflichen Pflegekontext steht das Thema „{primary}“ im Mittelpunkt. Ordne die Situation anhand der Lehrbuchangaben fachlich ein.'
    if any(t in types for t in {'communication','patient_education'}):
        return f'Bei der Betreuung eines Patienten steht das Thema „{primary}“ im Mittelpunkt. Beurteile die Situation anhand der Lehrbuchangaben und berücksichtige Kommunikation, Anleitung und pflegerisches Vorgehen.'
    if any(t in types for t in {'safety_rule','contraindication','complication'}):
        return f'Bei der Pflege eines Patienten steht das Thema „{primary}“ im Mittelpunkt. Beurteile die Situation anhand der Lehrbuchangaben und berücksichtige die beschriebenen Sicherheitsaspekte.'
    if any(t in types for t in {'procedure','intervention','sequence','medication'}):
        return f'Bei der Pflege eines Patienten steht das Thema „{primary}“ im Mittelpunkt. Übertrage die Lehrbuchangaben auf das pflegerische Vorgehen.'
    if any(t in types for t in {'sign','symptom','risk_factor','cause'}):
        return f'Bei der Beobachtung eines Patienten steht das Thema „{primary}“ im Mittelpunkt. Ordne die Situation anhand der Lehrbuchangaben fachlich ein.'
    return f'Bei der Pflege eines Patienten steht das Thema „{primary}“ im Mittelpunkt. Ordne die Situation anhand der Lehrbuchangaben fachlich ein.'

def source_question_stem(concept):
    title=clean_title(concept.get('title') or 'diesem Thema')
    typ=concept.get('type')
    if typ=='definition': return f'Wie wird „{title}“ im Lehrbuch definiert?'
    if typ=='normal_value': return f'Welche Angabe nennt das Lehrbuch zu „{title}“?'
    if typ in {'safety_rule','contraindication'}: return f'Welchen Sicherheitshinweis nennt das Lehrbuch zu „{title}“?'
    if typ in {'intervention','procedure'}: return f'Welches Vorgehen nennt das Lehrbuch zu „{title}“?'
    if typ=='communication': return f'Wie soll die Pflegekraft bei „{title}“ vorgehen?'
    if typ=='patient_education': return f'Welche Anleitung oder Information nennt das Lehrbuch zu „{title}“?'
    if typ in {'sign','symptom'}: return f'Welche Befunde nennt das Lehrbuch zu „{title}“?'
    if typ=='risk_factor': return f'Welchen Risikozusammenhang nennt das Lehrbuch zu „{title}“?'
    if typ=='complication': return f'Welche Komplikation nennt das Lehrbuch zu „{title}“?'
    if typ=='medication': return f'Welche medikamentenbezogene Aussage nennt das Lehrbuch zu „{title}“?'
    if typ=='sequence': return f'Welche Abfolge nennt das Lehrbuch zu „{title}“?'
    if typ in {'comparison','classification'}: return f'Wie ordnet das Lehrbuch „{title}“ ein?'
    if typ=='cause': return f'Welche Ursache nennt das Lehrbuch zu „{title}“?'
    return f'Welche Kernaussage nennt das Lehrbuch zu „{title}“?'

def question_prompt(scenario, concept, idx):
    # Keep each question self-contained because the current study UI presents clinical_case items individually.
    return f'{scenario}\n\nAufgabe {idx}: {source_question_stem(concept)}'


# Collect candidate sections.
candidates=[]
for sid,sec in section_by_id.items():
    sc=section_score(sid)
    if sc is None: continue
    candidates.append((sc,sid))
candidates.sort(reverse=True)

# Selection strategy: maximize chapter breadth first, then add highest-value second cases.
selected_sections=[]
used=set()
by_chapter=defaultdict(list)
for sc,sid in candidates:
    ch=section_by_id[sid]['chapterId']
    by_chapter[ch].append((sc,sid))

# One strongest case from every chapter that has enough source-backed material.
for chapter in sorted(chapters,key=lambda x:int(x.get('number') or 999)):
    opts=by_chapter.get(chapter['id']) or []
    if opts:
        sid=opts[0][1]
        selected_sections.append(sid); used.add(sid)

# Fill remaining cases by global utility, cap at 3 generated cases/chapter to avoid concentration.
per_chapter=Counter(section_by_id[sid]['chapterId'] for sid in selected_sections)
for sc,sid in candidates:
    if len(selected_sections)>=TARGET_NEW_CASES: break
    if sid in used: continue
    ch=section_by_id[sid]['chapterId']
    if per_chapter[ch]>=3: continue
    selected_sections.append(sid); used.add(sid); per_chapter[ch]+=1

if len(selected_sections)<TARGET_NEW_CASES:
    raise RuntimeError(f'Only {len(selected_sections)} suitable case sections available')
selected_sections=selected_sections[:TARGET_NEW_CASES]

new_cases=[]
new_questions=[]
source_card_ids=[]

for n,sid in enumerate(selected_sections,1):
    sec=section_by_id[sid]
    chapter=chapter_by_id[sec['chapterId']]
    usable=[]
    for c in concepts_by_section[sid]:
        for card in cards_by_concept.get(c['id'],[]):
            if usable_card(c, card):
                usable.append((c,card)); break
    usable.sort(key=lambda x:concept_score(*x),reverse=True)

    # Pick two distinct concept anchors. Prefer different concept types when possible.
    first=usable[0]
    second=None
    first_title=norm(clean_title(first[0].get('title') or ''))
    for cand in usable[1:]:
        cand_title=norm(clean_title(cand[0].get('title') or ''))
        if cand[0]['id']!=first[0]['id'] and cand_title!=first_title and cand[0].get('type')!=first[0].get('type'):
            second=cand; break
    if second is None:
        for cand in usable[1:]:
            cand_title=norm(clean_title(cand[0].get('title') or ''))
            if cand[0]['id']!=first[0]['id'] and cand_title!=first_title:
                second=cand; break
    if second is None:
        raise RuntimeError(f'No distinct second concept title for {sid}')
    selected=[first,second]

    scenario=scenario_for(sec,chapter,selected)
    case_id=f'case-p13-{n:03d}'
    qids=[]
    cids=[]
    for idx,(concept,card) in enumerate(selected,1):
        qid=f'q-p13-case-{n:03d}-{idx}'
        q={
            'id': qid,
            'conceptIds': [concept['id']],
            'type': 'clinical_case',
            'prompt': question_prompt(scenario,concept,idx),
            'correctText': card['back'],
            'explanation': card['back'],
            'difficulty': min(3,max(2,int(concept.get('difficulty') or 2))),
            'status': 'approved',
            'certification': 'p13-source-card-derived+automated-qa',
            'source': {
                'sectionId': sid,
                'chapterId': sec['chapterId'],
                'printedPages': (concept.get('source') or {}).get('printedPages',[]),
                'evidenceRefs': (concept.get('source') or {}).get('evidenceRefs',[]),
                'sourceCertification': concept.get('certification')
            },
            'generation': {
                'phase':'P13',
                'method':'conservative-source-fact-application',
                'sourceCardId':card['id'],
                'sharedCaseId':case_id
            }
        }
        new_questions.append(q); qids.append(qid); cids.append(concept['id']); source_card_ids.append(card['id'])

    case={
        'id':case_id,
        'title':f'Anwendungsfall: {clean_title(selected[0][0].get("title") or sec["title"])}',
        'scenario':scenario,
        'conceptIds':cids,
        'questionIds':qids,
        'provenance':'source_facts_synthesized',
        'status':'approved',
        'certification':'p13-source-card-derived+automated-qa',
        'source':{
            'sectionId':sid,
            'chapterId':sec['chapterId'],
            'printedPages':sorted({p for c,_ in selected for p in ((c.get('source') or {}).get('printedPages') or [])})
        }
    }
    new_cases.append(case)

all_questions=questions+new_questions
all_cases=cases_existing+new_cases

errors=[]
def err(msg): errors.append(msg)

# Integrity gates.
q_ids=[q['id'] for q in all_questions]
case_ids=[c['id'] for c in all_cases]
concept_ids={c['id'] for c in concepts}
card_by_id={c['id']:c for c in cards}
question_by_id={q['id']:q for q in all_questions}

if len(q_ids)!=len(set(q_ids)): err('duplicate question ids')
if len(case_ids)!=len(set(case_ids)): err('duplicate case ids')
if len(new_cases)!=TARGET_NEW_CASES: err('wrong new case count')
if len(all_cases)!=TARGET_TOTAL_CASES: err('wrong total case count')
if len(new_questions)!=TARGET_NEW_CASES*2: err('every new case must have exactly two generated questions')

for c in new_cases:
    if len(c['questionIds'])!=2: err(f'{c["id"]}: wrong question count')
    if len(set(c['conceptIds']))!=2: err(f'{c["id"]}: concept anchors not distinct')
    if any(cid not in concept_ids for cid in c['conceptIds']): err(f'{c["id"]}: invalid concept')
    if any(qid not in question_by_id for qid in c['questionIds']): err(f'{c["id"]}: invalid question')

for q in new_questions:
    cid=q['conceptIds'][0]
    source_id=q['generation']['sourceCardId']
    source=card_by_id.get(source_id)
    if not source or source['conceptId']!=cid: err(f'{q["id"]}: source lineage mismatch')
    if norm(q['correctText'])!=norm(source['back']): err(f'{q["id"]}: answer differs from source card')
    if norm(q['explanation'])!=norm(source['back']): err(f'{q["id"]}: explanation differs from source card')
    if any(p in q['prompt'] or p in q['correctText'] for p in BAD_TEXT_PATTERNS): err(f'{q["id"]}: bad text artifact')

# Avoid exact repeated stems/scenarios.
if len({norm(x['prompt']) for x in new_questions})!=len(new_questions): err('duplicate generated prompts')
if len({norm(x['scenario']) for x in new_cases})!=len(new_cases): err('duplicate generated scenarios')

# Coverage / distribution.
case_chapters={c['source']['chapterId'] for c in new_cases}
safety_case_concepts={cid for c in new_cases for cid in c['conceptIds'] if concept_by_id[cid].get('safetySensitive') or concept_by_id[cid].get('type')=='safety_rule'}
core_case_concepts={cid for c in new_cases for cid in c['conceptIds'] if concept_by_id[cid].get('importance')=='core'}
applied_types={'safety_rule','contraindication','intervention','procedure','communication','patient_education','complication','sign','symptom','risk_factor','medication','sequence'}
applied_count=sum(1 for c in new_cases if any(concept_by_id[cid].get('type') in applied_types for cid in c['conceptIds']))

if len(case_chapters)<50: err(f'chapter breadth too low: {len(case_chapters)}')
if len(safety_case_concepts)<55: err(f'safety concept coverage too low: {len(safety_case_concepts)}')
if applied_count<45: err(f'applied case count too low: {applied_count}')

report={
    'phase':'P13',
    'status':'PASS' if not errors else 'FAIL',
    'baseline':{
        'cases':len(cases_existing),
        'questions':len(questions),
    },
    'expansion':{
        'newCases':len(new_cases),
        'totalCases':len(all_cases),
        'newClinicalCaseQuestions':len(new_questions),
        'totalQuestions':len(all_questions),
        'questionsPerNewCase':2,
    },
    'coverage':{
        'chaptersRepresentedByNewCases':len(case_chapters),
        'chapterIds':sorted(case_chapters,key=lambda x:int(x.split('-')[1])),
        'uniqueCoreConceptsInNewCases':len(core_case_concepts),
        'uniqueSafetyConceptsInNewCases':len(safety_case_concepts),
        'newCasesWithAppliedOrSafetyDemand':applied_count,
    },
    'design':{
        'method':'Two source-backed retrieval prompts are grouped under one conservative synthesized scenario. No external clinical facts are added.',
        'caseQuestionMode':'clinical_case/self-graded',
        'sourceEditionYear':2015,
        'typingMandatory':False,
        'sharedScenarioStoredInCasesJson':True,
        'questionsRemainSelfContainedForCurrentStudyUI':True,
    },
    'qualityGates':{
        'uniqueQuestionIds':len(q_ids)==len(set(q_ids)),
        'uniqueCaseIds':len(case_ids)==len(set(case_ids)),
        'validReferences':not any('invalid' in e for e in errors),
        'sourceCardAnswerIdentity':not any('answer differs' in e or 'source lineage' in e for e in errors),
        'cleanGeneratedText':not any('bad text' in e for e in errors),
        'chapterBreadthAtLeast50':len(case_chapters)>=50,
        'safetyConceptsAtLeast55':len(safety_case_concepts)>=55,
        'appliedCasesAtLeast45':applied_count>=45,
        'errors':errors,
    },
    'selectedSourceCardIds':source_card_ids,
}

if errors:
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(1)

(DATA/'questions.json').write_text(json.dumps(all_questions,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(DATA/'cases.json').write_text(json.dumps(all_cases,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'P13_CASE_EXPANSION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

manifest=json.loads((DATA/'manifest.json').read_text(encoding='utf-8'))
manifest['phase']='P13'
manifest['version']='1.1.0-dev.13'
manifest['status']='p13-case-expansion-certified'
notes=list(manifest.get('notes') or [])
msg='P13 expands the source-faithful application bank to 120 cases using conservative synthesized scenarios backed by certified 2015 textbook concepts.'
if msg not in notes: notes.append(msg)
manifest['notes']=notes
(DATA/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

print(json.dumps(report,ensure_ascii=False,indent=2))

from __future__ import annotations
import json, os, re, math, hashlib, unicodedata, random
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

ROOT = Path(os.environ.get('PFLEGELERN_ROOT', '.')).resolve()
DATA = ROOT / 'data'

concepts = json.loads((DATA/'concepts.json').read_text(encoding='utf-8'))
cards = json.loads((DATA/'cards.json').read_text(encoding='utf-8'))
questions_existing = json.loads((DATA/'questions.json').read_text(encoding='utf-8'))
sections = json.loads((DATA/'sections.json').read_text(encoding='utf-8'))
chapters = json.loads((DATA/'chapters.json').read_text(encoding='utf-8'))

concept_by_id = {x['id']: x for x in concepts}
card_by_concept = {x['conceptId']: x for x in cards}
section_by_id = {x['id']: x for x in sections}
chapter_by_id = {x['id']: x for x in chapters}

# Source-checked repairs for user-facing cards that would otherwise seed malformed questions.
# These are conservative paraphrases of the cited 2015 textbook passages; no outside facts are added.
CARD_REPAIRS = {
    'concept-14-290-6-wissen-1': 'CPR beginnen, während andere das Reanimationsteam rufen und die Reanimationsausrüstung holen; Einzelhelfer verlassen den Patienten dafür kurz. Gegebenenfalls ein Reanimationsbrett unterlegen; 30 Thoraxkompressionen mit 2 Atemspenden abwechseln; Atemwege z. B. mit einem Guedel-Tubus freihalten.',
    'concept-14-293-30-achtung-1': 'Frakturen großer Röhrenknochen wie Humerus und Femur können einen erheblichen Blutverlust verursachen; deshalb steht die Überwachung der Vitalzeichen mit im Vordergrund.',
    'concept-24-474-6-wissen-4': 'Materialien für Punktion und Schutzverband vorbereiten; benötigte Infusionen aseptisch richten und mit Patientennamen, Zeitpunkt, Inhalt und Laufzeit beschriften; den Patienten lagern und einen Spritzschutz unter den Arm legen; je nach Hausstandard ggf. die Punktionsstelle rasieren; bei schlecht darstellbaren Venen kann vor der Punktion ein feuchtwarmer Wickel angelegt werden.',
    'concept-24-474-6-wissen-5': 'Beim Legen der Venenverweilkanüle assistieren und Material anreichen; anschließend einen Schutzverband anlegen; angeordnete Infusionen anhängen oder die Kanüle mittels Mandrin verschließen und schützend fixieren.',
    'concept-26-525-29-definition-1': 'Bei einer Lumbalpunktion wird im Bereich der Lendenwirbel der Duralsack punktiert, um Liquor zu entnehmen. Die Hohlnadel wird dabei zwischen den Dornfortsätzen des 2.–5. Lendenwirbels in den Lumbalkanal eingeführt.',
    'concept-31-609-59-definition-1': 'Eine Frühgeburt ist eine Lebendgeburt vor der vollendeten 37. Schwangerschaftswoche.',
    'concept-36-677-45-wissen-1': 'Medikamente in verschließbaren Schränken oder Kühlschränken aufbewahren; nach dem First-in-First-out-Prinzip lagern; Arzneimittel nur in ihrer Originalverpackung aufbewahren.',
    'concept-46-821-2-achtung-1': 'Immer unverzüglich einen Arzt informieren, wenn ein Sterbender subjektiv unter Luftnot leidet; häufig ist eine symptomatische Linderung möglich.',
    'concept-51-868-48-definition-1': 'Nesteln – ähnlich wie „Flockenlesen“ – ist ein Zeichen motorischer Unruhe und tritt häufig im Zusammenhang mit sensorischer Deprivation auf.',
    'concept-54-930-78-wissen-3': 'Beim Aneurysma dissecans ist die Gefäßwand gespalten; häufig ist die thorakale Aorta betroffen. Ein typisches Symptom ist ein starker Schmerz vom Brustkorb in den Rücken. Die Diagnostik erfolgt per Kontrastmittel-CT; die Therapie erfordert eine rasche Operation im Gefäßzentrum. Pflegerisch werden u. a. i.v.-Zugang, Monitoring und Transport vorbereitet.',
    'concept-55-948-22-achtung-1': 'Einen Arzt informieren, wenn nach der Bronchoskopie eines oder mehrere Warnsymptome auftreten, und die Vitalwerte des Patienten kontrollieren.',
    'concept-56-985-80-wissen-1': 'Bei der ERCP werden Gallen- und/oder Pankreasgänge nach Kontrastmittelgabe im Röntgenbild dargestellt; der Katheter wird über die Papilla Vateri im Duodenum eingeführt.',
    'concept-60-1200-39-definition-1': 'Rheumatische Erkrankungen umfassen zahlreiche entzündliche und degenerative Erkrankungen von Gelenken, Sehnen, Knochen, Muskeln und Bindegewebe. Das Lehrbuch teilt sie in vier Hauptgruppen ein: entzündlich-rheumatische Erkrankungen, degenerative Gelenk- und Wirbelsäulenerkrankungen, Weichteilrheumatismus sowie Stoffwechselerkrankungen mit rheumatischen Beschwerden.',
    'concept-62-1308-27-definition-1': 'Das Akustikusneurinom ist ein gutartiger Tumor des 8. Hirnnervs (Nervus vestibulocochlearis).',
    'concept-64-1370-58-definition-1': 'Von einer Phimose spricht man, wenn sich die Vorhaut nach dem 3. Lebensjahr nicht oder nur unter Schmerzen hinter die Eichel zurückstreifen lässt.',
    'concept-8-164-11-definition-1': 'Supervision ist ein wissenschaftlich fundiertes, praxisorientiertes und ethisch gebundenes Konzept für personen- und organisationsbezogene Beratung in der Arbeitswelt.',
    'concept-9-197-48-definition-1': 'Pflegeorganisationssysteme beschreiben, wie Pflegearbeit und Pflegeabläufe im Team organisiert werden. Das Lehrbuch unterscheidet hauptsächlich Funktionspflege, Bereichspflege und patientenorientierte Bezugspflege.',
    'concept-16-323-37-achtung-1': 'Liegt die Pulsfrequenz unter 45/min, sofort einen Arzt informieren; selbst in Ruhe ist die Sauerstoffversorgung dann in der Regel nicht mehr gewährleistet und häufig liegt eine gefährliche Herzrhythmusstörung vor.',
    'concept-3-41-79-definition-1': 'Ein Beruf ist eine dauerhaft angelegte Arbeit, die in der Regel eine Ausbildung voraussetzt und meist gegen Bezahlung ausgeübt wird.',
    'concept-48-845-22-definition-1': 'Ein Mensch gilt laut Bundesärztekammer als tot, wenn alle seine Hirnfunktionen irreversibel ausgefallen sind (dissoziierter Hirntod).',
    'concept-62-1302-19-definition-1': 'Tinnitus ist ein Pfeifen, Piepsen oder Rauschen im Ohr, das in der Regel nur der Betroffene hört; es kann ein- oder beidseitig auftreten.',
    'concept-66-1417-51-definition-1': 'Tollwut ist eine durch das Rabies-/Lyssa-Virus verursachte, in Deutschland sehr seltene und meist importierte Entzündung von Gehirn oder Rückenmark, die in der Regel tödlich verläuft; sie ist meldepflichtig.',
    'concept-9-178-21-definition-1': 'Körperschaften des öffentlichen Rechts werden in der Regel durch oder aufgrund eines Gesetzes gegründet, nehmen öffentliche Aufgaben wahr, haben Mitglieder mit Mitwirkungsmöglichkeiten und sind rechtsfähig.',
    'concept-12-260-75-achtung-1': 'Halten Sie Rücksprache mit einem Arzt, wenn Sie der Meinung sind, dass die Verschreibung eines Arzneimittels fehlerhaft ist.',
    'concept-19-375-35-merken-1': 'Auf den Schnabelbecher verzichten, außer der Patient verlangt ihn, weil er daran gewöhnt ist.',
    'concept-20-387-38-definition-1': 'Unter Stuhlinkontinenz versteht man das Unvermögen, Stuhl zurückzuhalten. Die Stuhlinkontinenz kann verschiedene medizinische und psychische Ursachen haben.',
    'concept-45-806-7-definition-1': 'Eine Transplantation ist eine operative Übertragung eines Organs, eines Organteils oder von Gewebe an eine andere Stelle des Körpers oder auf ein anderes Lebewesen.',
    'concept-57-1038-45-achtung-1': 'Bei Verdacht auf eine Nachblutung sofort den Arzt informieren.',
    'concept-61-1227-75-definition-1': 'Nach einem Schlaganfall kann eine zentrale Fazialisparese auftreten. Dabei ist die Gesichtsmuskulatur gelähmt; hauptsächlich betroffen ist die Gesichtsseite gegenüber der geschädigten Hirnhemisphäre, besonders Mund- und Wangenmuskulatur.',
    'concept-61-1230-49-definition-1': 'Aphasien sind durch Hirnschäden erworbene Störungen der Sprache.',
    'concept-63-1324-9-definition-1': 'Beim Hirsutismus findet sich bei Frauen und Kindern eine verstärkte Körperbehaarung, die dem männlichen Behaarungstyp entspricht.',
    'concept-66-1421-52-definition-1': 'Malaria ist eine in den (Sub-)Tropen erworbene, durch Plasmodien verursachte Infektion, die mit teils wiederkehrendem Fieber einhergeht und durch Anämie sowie Organdurchblutungsstörungen lebensbedrohlich werden kann. Übertragen wird sie durch die Anopheles-Mücke; es besteht Meldepflicht.',
    'concept-54-930-78-wissen-2': 'Falsches Aneurysma: Hämatom, z. B. durch Punktion; häufig nach Koronarangiografie; auf eine plötzlich auftretende Schwellung im Leistenbereich achten.',
    'concept-60-1170-4-wissen-1': 'Bei einer Patellafraktur kann das Knie nicht mehr gestreckt werden; weitere Symptome sind Schmerzen, Schwellung, Hämatome und ggf. ein Kniegelenkerguss.',
    'concept-60-1170-4-wissen-5': 'Bei einer Kreuzbandruptur erfolgt laut Lehrbuch meist die Ruhigstellung in einer Kniegelenkorthese mit anschließender intensiver Physiotherapie zum Muskelaufbau.'
}

CARD_FRONT_REPAIRS = {
    'concept-60-1170-4-wissen-1': 'Welche Symptome nennt das Lehrbuch bei einer Patellafraktur?',
    'concept-60-1170-4-wissen-5': 'Welche Therapie nennt das Lehrbuch bei einer Kreuzbandruptur?'
}

# Apply source-checked card repairs in-memory so the question lineage and the learner-facing card agree.
repaired_card_ids = []
for concept_id, new_back in CARD_REPAIRS.items():
    card = card_by_concept[concept_id]
    if concept_id in CARD_FRONT_REPAIRS:
        card['front'] = CARD_FRONT_REPAIRS[concept_id]
    if card['back'] != new_back:
        card['back'] = new_back
        flags = list(card.get('qaFlags') or [])
        if 'p12-source-repair' not in flags:
            flags.append('p12-source-repair')
        card['qaFlags'] = flags
        card['certification'] = 'p12-source-repaired+source-checked'
        repaired_card_ids.append(card['id'])

# Helpers
STOP = set('''der die das ein eine einer eines einem einen und oder von vom zur zum zu bei im in auf für mit als des den dem ist sind wird werden wurde wurden laut lehrbuch pflege patient patienten grundlagen definition allgemeines wichtig besonders hinweise regel maßnahmen maßnahme pflegende pflegekraft allgemein zusammenhang verschiedene verschiedenen thema erkrankung erkrankungen'''.split())
BAD_OPTION_PATTERNS = [
    re.compile(r'\.\s*;'),
    re.compile(r'\baufbewah\.$', re.I),
    re.compile(r'\bPRC\b'),
    re.compile(r'organisa\s+tions', re.I),
    re.compile(r'einen Arzt, wenn', re.I),
    re.compile(r'ein Zeichen motorische Unruhe', re.I),
    re.compile(r':\s*;'),
    re.compile(r'\b\d+\.$'),
    re.compile(r'\bi\.\s*d\.\s*$', re.I),
    re.compile(r'alle\s+s\s+eine', re.I),
    re.compile(r'\b(?:P\s+atient|O\s+rgan|S\s+prache|z\s+urück|v\s+ermeid)', re.I),
    re.compile(r'sollten\s+Rücksprache\s+mit\s+einem\s+Arzt,', re.I),
    re.compile(r'bei Verdacht auf eine Nachblutung sofort den Arzt\.$', re.I),
    re.compile(r',\s*v\.\s*a\.\s*$', re.I),
    re.compile(r'\.\s*a\.\s*$', re.I),
    re.compile(r'mit\s+[–-]\s*u\.\s*$', re.I),
    re.compile(r'\bTibiakopffraktur\s+Grundlagen\b', re.I),
    re.compile(r'[\x00-\x08\x0b\x0c\x0e-\x1f\ufffd]'),
]

def norm(s: str) -> str:
    s = unicodedata.normalize('NFKC', s).lower()
    s = re.sub(r'\s+', ' ', s)
    s = re.sub(r'[^\wäöüß]+', ' ', s)
    return ' '.join(s.split())

def title_tokens(title: str):
    return {t for t in norm(title).split() if t not in STOP and len(t) > 2}

def is_clean_text(text: str) -> bool:
    if not isinstance(text, str): return False
    t = text.strip()
    if len(t) < 5 or len(t) > 520: return False
    return not any(p.search(t) for p in BAD_OPTION_PATTERNS)

def source_meta(concept_id: str):
    c = concept_by_id[concept_id]
    src = c.get('source') or {}
    return {
        'conceptId': concept_id,
        'sectionId': c.get('sectionId'),
        'chapterId': c.get('chapterId'),
        'printedPages': src.get('printedPages') or [],
        'evidenceRefs': src.get('evidenceRefs') or [],
        'evidenceRecordIds': src.get('evidenceRecordIds') or [],
        'sourceCertification': c.get('certification')
    }

def prompt_for(c):
    title = c['title']
    typ = c.get('type')
    if typ == 'definition':
        return f'Welche Beschreibung passt laut Lehrbuch am besten zu „{title}“?'
    if typ == 'normal_value':
        return f'Welche Angabe passt laut Lehrbuch zu „{title}“?'
    if typ == 'safety_rule':
        return f'Welche Aussage ist bei „{title}“ laut Lehrbuch besonders zu beachten?'
    if typ in ('intervention', 'procedure'):
        return f'Welche Aussage beschreibt das passende Vorgehen bei „{title}“?'
    if typ == 'communication':
        return f'Welche Vorgehensweise passt laut Lehrbuch zu „{title}“?'
    if typ in ('comparison', 'classification'):
        return f'Welche Aussage ordnet „{title}“ korrekt ein?'
    if typ in ('cause','risk_factor','complication','symptom','sign'):
        return f'Welche Aussage gehört laut Lehrbuch zu „{title}“?'
    return f'Welche Aussage trifft laut Lehrbuch auf „{title}“ zu?'

def learning_demand(c):
    typ = c.get('type')
    if c.get('safetySensitive') or typ == 'safety_rule': return 'safety'
    if typ in ('procedure','sequence'): return 'sequence_procedure'
    if typ in ('intervention','communication','patient_education'): return 'applied_judgment'
    if typ in ('definition','classification','comparison','normal_value'): return 'discrimination'
    if typ in ('principle',): return 'conceptual_explanation'
    return 'factual_recall'

def split_enumeration(text: str):
    t = text.strip().rstrip('.')
    # Prefer semicolon-separated source lists.
    if ';' in t:
        parts = [p.strip(' .!') for p in t.split(';')]
    else:
        # Split commas, then a single final "und"/"sowie" where it is list-like.
        parts = [p.strip(' .!') for p in re.split(r',\s*', t)]
        if len(parts) >= 2:
            last = parts[-1]
            m = re.match(r'(.+?)\s+(?:und|sowie)\s+(.+)$', last, re.I)
            if m and all(len(x.split()) <= 10 for x in m.groups()):
                parts[-1:] = [m.group(1).strip(), m.group(2).strip()]
    parts = [re.sub(r'^\d+[.)]\s*', '', p).strip() for p in parts if p.strip()]
    # Avoid fragments that only make sense as sentence continuations.
    if not (3 <= len(parts) <= 7): return None
    if any(len(p) < 3 or len(p) > 120 for p in parts): return None
    if len({norm(p) for p in parts}) != len(parts): return None
    return parts

# Build TF-IDF similarity over repaired answers.
texts = [c['back'] for c in cards]
vectorizer = TfidfVectorizer(lowercase=True, ngram_range=(1,2), min_df=1)
X = vectorizer.fit_transform(texts)
card_index = {c['id']: i for i,c in enumerate(cards)}

# Concepts with existing assessment coverage.
existing_covered = {cid for q in questions_existing for cid in q.get('conceptIds', [])}
core_ids = {c['id'] for c in concepts if c.get('importance') == 'core'}
safety_ids = {c['id'] for c in concepts if c.get('safetySensitive')}
procedure_ids = {c['id'] for c in concepts if c.get('type') in ('procedure','sequence')}
eligible_ids = core_ids | safety_ids | procedure_ids
target_ids = sorted(eligible_ids - existing_covered)

# A small set of concepts intentionally share a title but test different facets. Give them
# explicit, learner-readable stems rather than machine-like title collisions.
PROMPT_OVERRIDES = {
    'concept-14-290-6-wissen-1': 'Welche Maßnahmen nennt das Lehrbuch zu Beginn der kardiopulmonalen Reanimation (Teil 1/2)?',
    'concept-14-290-6-wissen-2': 'Welche weiteren Maßnahmen nennt das Lehrbuch zur kardiopulmonalen Reanimation (Teil 2/2)?',
    'concept-21-436-87-wissen-1': 'Welche medikamentenbezogenen Risikofaktoren nennt das Lehrbuch zur Sturzprophylaxe?',
    'concept-21-436-87-wissen-2': 'Welche umgebungsbezogenen Risikofaktoren nennt das Lehrbuch zur Sturzprophylaxe?',
    'concept-24-474-6-wissen-1': 'Wofür wird eine Venenverweilkanüle laut Lehrbuch eingesetzt und wie lange liegt sie typischerweise?',
    'concept-24-474-6-wissen-2': 'Welche Aussage beschreibt den Midline-Katheter laut Lehrbuch?',
    'concept-24-474-6-wissen-3': 'Welche Aussage beschreibt die Butterflykanüle laut Lehrbuch?',
    'concept-24-474-6-wissen-4': 'Welche Maßnahmen gehören laut Lehrbuch zur Vorbereitung eines periphervenösen Gefäßzugangs?',
    'concept-24-474-6-wissen-5': 'Welche Maßnahmen gehören laut Lehrbuch zur Assistenz und Nachbereitung beim Legen einer Venenverweilkanüle?',
    'concept-24-489-19-wissen-3': 'Welche Aussage beschreibt Dreiwegehähne als Infusionszubehör?',
    'concept-24-489-19-wissen-5': 'Welche Aussage beschreibt Mehrfachverbindungen als Infusionszubehör?',
    'concept-24-491-20-wissen-1': 'Was soll bei der Überwachung einer Infusionstherapie kontrolliert bzw. dokumentiert werden?',
    'concept-24-491-20-wissen-2': 'Welche zentrale Dokumentationsanforderung nennt das Lehrbuch bei Infusionstherapien?',
    'concept-28-557-52-wissen-1': 'Welche Maßnahme nennt das Lehrbuch bei Verwendung einer Nasensonde zur Sauerstofftherapie?',
    'concept-28-557-52-wissen-2': 'Welche allgemeinen Pflegemaßnahmen nennt das Lehrbuch bei der Sauerstofftherapie?',
    'concept-36-678-55-achtung-1': 'Was ist beim Stellen von Medikamenten laut Lehrbuch besonders zu beachten?',
    'concept-36-679-69-achtung-1': 'Was darf beim Stellen von Medikamenten laut Lehrbuch keinesfalls geschehen?',
    'concept-54-930-78-wissen-2': 'Welche Aussage beschreibt das falsche Aneurysma (Aneurysma spurium) laut Lehrbuch?',
    'concept-54-930-78-wissen-3': 'Welche Aussage beschreibt das Aneurysma dissecans laut Lehrbuch?',
    'concept-55-950-39-achtung-1': 'Welche Warnung gibt das Lehrbuch zum Asthma-Anfall?',
    'concept-55-953-32-achtung-1': 'Was empfiehlt das Lehrbuch, wenn ein Asthma-Patient unter Luftnot leidet?',
    'concept-57-1035-28-wissen-1': 'Wie wird bei einem Patienten mit Dauerkatheter eine Urinprobe entnommen?',
    'concept-57-1035-28-wissen-3': 'Welche Schritte nennt das Lehrbuch für Mittelstrahl- und Sammelurin (Teil 1/2)?',
    'concept-57-1035-28-wissen-4': 'Welche weiteren Schritte nennt das Lehrbuch für Sammelurin (Teil 2/2)?',
    'concept-60-1164-79-wissen-1': 'Welche Symptome nennt das Lehrbuch bei Frakturen am Oberarm?',
    'concept-60-1164-79-wissen-2': 'Welche Therapie nennt das Lehrbuch bei Frakturen am Oberarm?',
    'concept-60-1166-33-wissen-1': 'Welche Symptome nennt das Lehrbuch bei einer distalen Radiusfraktur?',
    'concept-60-1166-33-wissen-2': 'Welche Therapie nennt das Lehrbuch bei einer distalen Radiusfraktur?',
    'concept-60-1170-4-wissen-1': 'Welche Symptome nennt das Lehrbuch bei einer Patellafraktur?',
    'concept-60-1170-4-wissen-5': 'Welche Therapie nennt das Lehrbuch bei einer Kreuzbandruptur?',
    'concept-62-1289-33-wissen-1': 'Welche Symptome nennt das Lehrbuch bei einer Netzhautablösung?',
    'concept-62-1289-33-wissen-2': 'Welche Diagnostik nennt das Lehrbuch bei einer Netzhautablösung?',
    'concept-62-1289-33-wissen-3': 'Welche Therapie nennt das Lehrbuch bei einer Netzhautablösung?'
}

base_prompt_counts = Counter(prompt_for(concept_by_id[cid]) for cid in target_ids)
existing_prompt_norms = {norm(q.get('prompt','')) for q in questions_existing}

def generated_prompt_for(concept_id: str) -> str:
    if concept_id in PROMPT_OVERRIDES:
        return PROMPT_OVERRIDES[concept_id]
    c = concept_by_id[concept_id]
    base = prompt_for(c)
    sec = section_by_id.get(c.get('sectionId')) or {}
    label = (sec.get('title') or sec.get('number') or '').strip()
    # Definitions, classifications and normal values are naturally anchored by the concept label.
    # Broader rules/principles receive section context so a generic title such as "Kontrolle" is unambiguous.
    if c.get('type') in ('definition','classification','normal_value','comparison'):
        candidate = base
    elif label and norm(label) != norm(c.get('title','')):
        if c.get('type') == 'safety_rule':
            candidate = f'Welche Aussage ist laut Lehrbuch bei „{c["title"]}“ im Abschnitt „{label}“ besonders zu beachten?'
        elif c.get('type') in ('intervention','procedure'):
            candidate = f'Welche Aussage beschreibt laut Lehrbuch das Vorgehen bei „{c["title"]}“ im Abschnitt „{label}“?'
        else:
            candidate = f'Welche Aussage passt laut Lehrbuch zu „{c["title"]}“ im Abschnitt „{label}“?'
    else:
        candidate = base
    if norm(candidate) not in existing_prompt_norms:
        return candidate
    suffix = label or c.get('chapterId') or concept_id
    return candidate[:-1] + f' (Abschnitt „{suffix}“)?' if candidate.endswith('?') else f'{candidate} – Abschnitt „{suffix}“'

# Precompute target-to-all semantic similarities once; this avoids hundreds of sparse-kernel calls.
target_indices_for_similarity = [card_index[card_by_concept[cid]['id']] for cid in target_ids]
SIM = linear_kernel(X[target_indices_for_similarity], X)
sim_row_by_cid = {cid: SIM[i] for i, cid in enumerate(target_ids)}

card_meta = []
for i, cand_card in enumerate(cards):
    cand = concept_by_id.get(cand_card['conceptId'])
    card_meta.append({
        'i': i, 'card': cand_card, 'concept': cand,
        'clean': bool(cand and is_clean_text(cand_card['back'])),
        'norm_back': norm(cand_card['back']),
        'len': len(cand_card['back']),
        'title_tokens': title_tokens(cand['title']) if cand else set(),
        'tags': set(cand.get('tags') or []) if cand else set(),
    })

# Tags are sparse but useful when present; exclude same-tag distractors to reduce ambiguous options.
def distractors_for(concept_id: str, n=3):
    target_card = card_by_concept[concept_id]
    target = concept_by_id[concept_id]
    sims = sim_row_by_cid[concept_id]
    tlen = max(1, len(target_card['back']))
    tt = title_tokens(target['title'])
    ttags = set(target.get('tags') or [])
    candidates = []
    for m in card_meta:
        cand_card=m['card']; cand=m['concept']; i=m['i']
        if not m['clean'] or cand_card['conceptId'] == concept_id: continue
        if m['norm_back'] == norm(target_card['back']): continue
        ratio = m['len']/tlen
        if ratio < 0.35 or ratio > 2.8: continue
        ct=m['title_tokens']
        title_jaccard = len(tt & ct)/max(1,len(tt | ct)) if (tt or ct) else 0
        if title_jaccard >= 0.40: continue
        ctags=m['tags']
        if ttags and ctags and (ttags & ctags): continue
        same_ch = cand.get('chapterId') == target.get('chapterId')
        same_type = cand.get('type') == target.get('type')
        same_card_type = cand_card.get('type') == target_card.get('type')
        same_sec = cand.get('sectionId') == target.get('sectionId')
        discrete = target.get('type') in ('definition','classification','normal_value','comparison')
        # Related definitions benefit from within-chapter discrimination. For broad safety/summary/principle
        # stems, same-chapter options can also be true of the target situation, so exclude them.
        if same_ch and not discrete:
            continue
        score = float(sims[i]) + (0.18 if (same_ch and discrete) else 0) + (0.10 if same_type else 0) + (0.03 if same_card_type else 0) - (0.18 if same_sec else 0) - abs(math.log(ratio))*0.03
        candidates.append((score, cand_card, cand))
    candidates.sort(key=lambda x: x[0], reverse=True)
    out, seen = [], set()
    for score, cc, cand in candidates:
        nb = norm(cc['back'])
        if nb in seen: continue
        ans_tokens = set(nb.split())
        if len(tt) >= 2 and len(tt & ans_tokens) >= max(2, math.ceil(len(tt)*0.5)):
            continue
        out.append((score, cc, cand))
        seen.add(nb)
        if len(out) >= n: break
    if len(out) < n:
        raise RuntimeError(f'Not enough distractors for {concept_id}: {len(out)}')
    return out

def stable_order(items, key):
    return sorted(items, key=lambda x: hashlib.sha256((key + '|' + x[0]).encode('utf-8')).hexdigest())

new_questions = []
new_question_ids = set()

for idx, cid in enumerate(target_ids, start=1):
    c = concept_by_id[cid]
    card = card_by_concept[cid]
    qid = f'q-p12-{idx:04d}'
    if qid in new_question_ids:
        raise RuntimeError('duplicate generated id')
    new_question_ids.add(qid)

    parts = split_enumeration(card['back']) if card.get('type') == 'enumeration' else None
    if parts:
        # Build sourced distractor components from other clean enumeration cards in the same chapter first.
        pool = []
        for other in cards:
            if other['conceptId'] == cid or other.get('type') != 'enumeration': continue
            oc = concept_by_id[other['conceptId']]
            oparts = split_enumeration(other['back'])
            if not oparts: continue
            for p in oparts:
                if norm(p) in {norm(x) for x in parts}: continue
                score = (2 if oc.get('chapterId') == c.get('chapterId') else 0) + (1 if oc.get('type') == c.get('type') else 0)
                pool.append((score, p, oc['id']))
        pool.sort(key=lambda x: (-x[0], hashlib.sha256((qid+'|'+x[1]).encode()).hexdigest()))
        distractor_parts=[]
        distractor_sources=[]
        seen={norm(x) for x in parts}
        for _, p, ocid in pool:
            if norm(p) in seen or not is_clean_text(p): continue
            distractor_parts.append(p)
            distractor_sources.append(ocid)
            seen.add(norm(p))
            if len(distractor_parts) >= 2: break
        if len(distractor_parts) < 1:
            # Fall back to single-choice if the list cannot support clean distractors.
            parts = None
        else:
            all_opts=[('correct',p) for p in parts] + [('distractor',p) for p in distractor_parts]
            all_opts=stable_order(all_opts,qid)
            options=[]; correct=[]
            for j,(kind,text) in enumerate(all_opts):
                oid=chr(ord('a')+j)
                options.append({'id':oid,'text':text})
                if kind=='correct': correct.append(oid)
            q={
                'id': qid,
                'conceptIds':[cid],
                'type':'multiple_choice',
                'prompt':generated_prompt_for(cid),
                'difficulty': max(1, min(3, int(c.get('difficulty') or 2))),
                'explanation':'Richtig sind: ' + '; '.join(parts) + '.',
                'status':'approved',
                'options':options,
                'correct':correct,
                'certification':'p12-source-card-derived+automated-qa',
                'source':source_meta(cid),
                'generation':{
                    'phase':'P12','method':'enumeration-discrimination','sourceCardId':card['id'],
                    'distractorConceptIds':distractor_sources,'learningDemand':learning_demand(c)
                }
            }
            new_questions.append(q)
            continue

    # Default: objective single-choice discrimination using the certified target answer and sourced peer distractors.
    ds = distractors_for(cid,3)
    correct_text = card['back'].strip()
    options_raw=[('correct',correct_text,cid)] + [('distractor',dcard['back'].strip(), dcon['id']) for _,dcard,dcon in ds]
    options_raw=stable_order(options_raw,qid)
    options=[]; correct=[]; distractor_ids=[]
    for j,(kind,text,source_cid) in enumerate(options_raw):
        oid=chr(ord('a')+j)
        options.append({'id':oid,'text':text})
        if kind=='correct': correct.append(oid)
        else: distractor_ids.append(source_cid)
    q={
        'id':qid,
        'conceptIds':[cid],
        'type':'single_choice',
        'prompt':generated_prompt_for(cid),
        'difficulty':max(1,min(3,int(c.get('difficulty') or 2))),
        'explanation':'Richtig ist: ' + correct_text,
        'status':'approved',
        'options':options,
        'correct':correct,
        'certification':'p12-source-card-derived+automated-qa',
        'source':source_meta(cid),
        'generation':{
            'phase':'P12','method':'source-backed-discrimination','sourceCardId':card['id'],
            'distractorConceptIds':distractor_ids,'learningDemand':learning_demand(c)
        }
    }
    new_questions.append(q)

# Add 12 explicit same-section matching tasks to improve discrimination between confusable/related concepts.
# Restrict to concise definition/classification/normal-value concepts and distinct source-backed answers.
existing_matching_sets={frozenset(q.get('conceptIds',[])) for q in questions_existing if q.get('type')=='matching'}
section_groups=defaultdict(list)
for c in concepts:
    if c.get('importance') not in ('core','important'): continue
    if c.get('type') not in ('definition','classification','normal_value','comparison'): continue
    card=card_by_concept.get(c['id'])
    if not card or not is_clean_text(card['back']) or len(card['back'])>220: continue
    section_groups[c['sectionId']].append(c)

candidates=[]
for sid, group in section_groups.items():
    # Distinct titles/answers only; max 4 per task.
    unique=[]; seen_answers=set(); seen_titles=set()
    for c in sorted(group,key=lambda x:(0 if x.get('importance')=='core' else 1, x['id'])):
        card=card_by_concept[c['id']]
        if norm(card['back']) in seen_answers or norm(c['title']) in seen_titles: continue
        unique.append(c); seen_answers.add(norm(card['back'])); seen_titles.add(norm(c['title']))
    if len(unique)<3: continue
    # Prefer groups with more core concepts and shorter answers.
    score=sum(2 if c.get('importance')=='core' else 1 for c in unique) - sum(len(card_by_concept[c['id']]['back']) for c in unique[:4])/500
    candidates.append((score,sid,unique[:4]))
candidates.sort(key=lambda x:(-x[0], x[1]))

matching_added=0
for _,sid,group in candidates:
    ids=frozenset(c['id'] for c in group)
    if ids in existing_matching_sets: continue
    qid=f'q-p12-match-{matching_added+1:02d}'
    opts=[]
    for j,c in enumerate(group):
        answer=card_by_concept[c['id']]['back'].strip()
        # Keep pair display manageable; these were pre-filtered to <=220 chars.
        opts.append({'id':chr(ord('a')+j),'text':f'{c["title"]} ↔ {answer}'})
    chapter_id=group[0].get('chapterId')
    q={
        'id':qid,
        'conceptIds':[c['id'] for c in group],
        'type':'matching',
        'prompt':'Ordne die Begriffe den passenden Beschreibungen aus dem Lehrbuch zu.',
        'difficulty':2,
        'explanation':'Die Zuordnung verbindet jeden Begriff mit seiner source-basierten Kurzbeschreibung.',
        'status':'approved',
        'options':opts,
        'correct':[o['id'] for o in opts],
        'certification':'p12-source-card-derived+automated-qa',
        'source':{
            'sectionId':sid,'chapterId':chapter_id,
            'conceptSources':[source_meta(c['id']) for c in group]
        },
        'generation':{
            'phase':'P12','method':'same-section-matching','sourceCardIds':[card_by_concept[c['id']]['id'] for c in group],
            'learningDemand':'discrimination'
        }
    }
    new_questions.append(q)
    matching_added+=1
    if matching_added>=12: break

if matching_added < 12:
    raise RuntimeError(f'Could only generate {matching_added} matching tasks')

all_questions = questions_existing + new_questions

# ---------- Validation ----------
errors=[]

def err(msg): errors.append(msg)

if len(questions_existing)!=85: err(f'baseline question count changed: {len(questions_existing)}')
if len(all_questions)!=750: err(f'expected total 750, got {len(all_questions)}')
if len(new_questions)!=665: err(f'expected 665 new questions, got {len(new_questions)}')

ids=[q['id'] for q in all_questions]
if len(ids)!=len(set(ids)): err('duplicate question ids')
nprompts=[norm(q.get('prompt','')) for q in all_questions]
# Existing and generated questions may share generic matching wording, so only exact generated non-matching prompt duplicates are forbidden.
new_nonmatch=[norm(q['prompt']) for q in new_questions if q['type']!='matching']
if len(new_nonmatch)!=len(set(new_nonmatch)): err('duplicate generated non-matching prompts')

concept_ids=set(concept_by_id)
covered={cid for q in all_questions for cid in q.get('conceptIds',[])}
missing_eligible=sorted(eligible_ids-covered)
if missing_eligible: err(f'eligible concepts missing assessment coverage: {missing_eligible[:10]} (+{max(0,len(missing_eligible)-10)})')
if not core_ids <= covered: err('not all CORE concepts covered')
if not safety_ids <= covered: err('not all safety-sensitive concepts covered')
if not procedure_ids <= covered: err('not all procedure/sequence concepts covered')

# Every chapter containing eligible content must have question coverage.
q_by_ch=Counter()
for q in all_questions:
    chs={concept_by_id[cid].get('chapterId') for cid in q.get('conceptIds',[]) if cid in concept_by_id}
    for ch in chs:
        if ch: q_by_ch[ch]+=1
eligible_by_ch=Counter(concept_by_id[cid].get('chapterId') for cid in eligible_ids)
for ch,n in eligible_by_ch.items():
    if n and q_by_ch[ch]==0: err(f'eligible chapter without questions: {ch}')

# Structural and lineage checks.
for q in new_questions:
    if q.get('status')!='approved': err(f'{q["id"]}: not approved')
    if not q.get('conceptIds') or any(cid not in concept_ids for cid in q['conceptIds']): err(f'{q["id"]}: invalid concept refs')
    if not is_clean_text(q.get('prompt','')): err(f'{q["id"]}: dirty prompt')
    if q['type'] in ('single_choice','multiple_choice'):
        opts=q.get('options') or []
        oids=[o['id'] for o in opts]
        texts2=[norm(o['text']) for o in opts]
        if len(oids)!=len(set(oids)): err(f'{q["id"]}: duplicate option ids')
        if len(texts2)!=len(set(texts2)): err(f'{q["id"]}: duplicate option text')
        if any(not is_clean_text(o['text']) for o in opts): err(f'{q["id"]}: dirty option text')
        if not q.get('correct') or any(x not in oids for x in q['correct']): err(f'{q["id"]}: invalid correct refs')
        if q['type']=='single_choice' and len(q['correct'])!=1: err(f'{q["id"]}: single choice must have one correct')
        if q['type']=='multiple_choice' and (len(q['correct'])<2 or len(q['correct'])>=len(opts)): err(f'{q["id"]}: invalid multiple-choice correct count')
    elif q['type']=='matching':
        opts=q.get('options') or []
        if len(opts)<3 or any(' ↔ ' not in o['text'] for o in opts): err(f'{q["id"]}: malformed matching options')
    else:
        err(f'{q["id"]}: unsupported generated type {q["type"]}')
    if q.get('certification')!='p12-source-card-derived+automated-qa': err(f'{q["id"]}: wrong certification')
    if q['generation']['phase']!='P12': err(f'{q["id"]}: missing P12 lineage')

# Correct-answer lineage for every generated single/multiple question.
for q in new_questions:
    if q['type'] not in ('single_choice','multiple_choice'): continue
    cid=q['conceptIds'][0]
    source_card_id=q['generation']['sourceCardId']
    card=next((x for x in cards if x['id']==source_card_id),None)
    if not card or card['conceptId']!=cid: err(f'{q["id"]}: source card lineage mismatch')
    correct_texts={norm(o['text']) for o in q['options'] if o['id'] in q['correct']}
    if q['type']=='single_choice':
        if norm(card['back']) not in correct_texts: err(f'{q["id"]}: correct answer not sourced from target card')
    else:
        parts=split_enumeration(card['back'])
        if not parts or {norm(x) for x in parts} != correct_texts: err(f'{q["id"]}: enumeration correct answers do not match source card')

# No generated content contains old known extraction artifacts.
joined=json.dumps(new_questions,ensure_ascii=False)
for pattern,label in [
    ('aufbewah.', 'truncated aufbewahren'),('organisa tions','split organisations'),('PRC Gallen','broken ERCP'),('.;','dot-semicolon'),
    ('einen Arzt, wenn','missing inform'),('\ufffd','replacement char')]:
    if pattern in joined: err(f'generated content contains {label}')

# Preserve original 85 question records exactly.
if all_questions[:85] != questions_existing: err('baseline questions were modified')

# Coverage metrics.
type_counts=Counter(q['type'] for q in all_questions)
new_type_counts=Counter(q['type'] for q in new_questions)
cert_counts=Counter(q.get('certification','') for q in new_questions)
core_coverage=len(core_ids & covered)
safety_coverage=len(safety_ids & covered)
proc_coverage=len(procedure_ids & covered)

report={
    'phase':'P12',
    'status':'PASS' if not errors else 'FAIL',
    'branch':'p12-practice-question-expansion',
    'baselineQuestions':len(questions_existing),
    'newQuestions':len(new_questions),
    'totalQuestions':len(all_questions),
    'questionTypes':dict(sorted(type_counts.items())),
    'newQuestionTypes':dict(sorted(new_type_counts.items())),
    'coverage':{
        'core':{'covered':core_coverage,'total':len(core_ids),'ratio':round(core_coverage/len(core_ids),4)},
        'safetySensitive':{'covered':safety_coverage,'total':len(safety_ids),'ratio':round(safety_coverage/len(safety_ids),4)},
        'procedureOrSequence':{'covered':proc_coverage,'total':len(procedure_ids),'ratio':round(proc_coverage/len(procedure_ids),4)},
        'eligibleUnion':{'covered':len(eligible_ids & covered),'total':len(eligible_ids),'ratio':round(len(eligible_ids & covered)/len(eligible_ids),4)},
        'allConceptsWithAnyQuestion':len(covered),
        'allConcepts':len(concepts)
    },
    'chapters':{
        'total':len(chapters),
        'withQuestions':sum(1 for c in chapters if q_by_ch[c['id']]>0),
        'eligibleChaptersWithoutQuestions':[c['id'] for c in chapters if eligible_by_ch[c['id']]>0 and q_by_ch[c['id']]==0]
    },
    'sourceLineage':{
        'method':'Every generated correct answer is derived from the approved source-backed card for its target concept; distractors are drawn from other approved source-backed cards. Matching pairs use the same approved card bank.',
        'generatedCertification':dict(cert_counts),
        'sourceCheckedCardRepairs':len(repaired_card_ids),
        'repairedCardIds':repaired_card_ids
    },
    'qualityGates':{
        'uniqueQuestionIds':len(ids)==len(set(ids)),
        'uniqueGeneratedNonMatchingPrompts':len(new_nonmatch)==len(set(new_nonmatch)),
        'validConceptReferences':all(all(cid in concept_ids for cid in q.get('conceptIds',[])) for q in all_questions),
        'cleanGeneratedText':not any(label in joined for label in []),
        'allCoreCovered':core_ids <= covered,
        'allSafetySensitiveCovered':safety_ids <= covered,
        'allProcedureSequenceCovered':procedure_ids <= covered,
        'eligibleChapterCoverage':all(q_by_ch[ch]>0 for ch in eligible_by_ch if eligible_by_ch[ch]>0),
        'baseline85Preserved':all_questions[:85]==questions_existing,
        'errors':errors
    }
}

if errors:
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(1)

# Write outputs.
(DATA/'cards.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(DATA/'questions.json').write_text(json.dumps(all_questions,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'P12_QUESTION_EXPANSION_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
